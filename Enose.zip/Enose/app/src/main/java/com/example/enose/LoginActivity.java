package com.example.enose;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.text.TextUtils;

public class LoginActivity extends AppCompatActivity {
    private EditText inputUsername, inputPassword;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        setContentView(R.layout.activity_login);
        inputUsername = (EditText) findViewById(R.id.un);
        inputPassword = (EditText) findViewById(R.id.pd);
        button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Username = inputUsername.getText().toString();
                final String Password = inputPassword.getText().toString();
                if (Username.equals("Swapnil") && Password.equals("klaus"))
                {
                    Intent in = new Intent(LoginActivity.this, OptionActivity.class);
                    LoginActivity.Activity.startActivity(in);
                }
                else if (Username.equals("") || Password.equals(""))
                {
                    Toast.makeText(getBaseContext(), "Enter both Name & Password!", Toast.LENGTH_SHORT).show();

                }
                else
                    {
                    Toast.makeText(getBaseContext(), "Wrong Name & Password!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
