package com.example.enose;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class OptionActivity extends AppCompatActivity {
    private Button LOGOUT;
    private Button button4;
    Button Button4;
    private Button button3;
    Button Button3;
    private Button button2;
    Button Button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.option_activity);
        button4 = (Button) findViewById(R.id.button4);//notification button
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OptionActivity.this, NotificationActivity.class);
                startActivity(intent);
            }
        });
        button3 = (Button) findViewById(R.id.button3);//Maintainence button
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(OptionActivity.this, NotificationActivity1.class);
                startActivity(in);
            }
        });
        button2 = (Button) findViewById(R.id.button2) ;// Sensor Health
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(OptionActivity.this, NotificationActivity2.class);
                startActivity(i);
            }
        });
        LOGOUT=findViewById(R.id.button5);//logout
        LOGOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentL=new Intent(OptionActivity.this,MainActivity.class);
                startActivity(intentL);
                finish();
                Toast.makeText(OptionActivity.this,"SUCCESSFUL LOGOUT",Toast.LENGTH_SHORT).show();
            }
        });
    }

}


