package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    private Button LOGOUT;
    private Button button4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                opennotificationin();
            }
        });
        LOGOUT=findViewById(R.id.button5);
        LOGOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentL=new Intent(Main2Activity.this,MainActivity.class);
                startActivity(intentL);
                finish();
                Toast.makeText(Main2Activity.this,"SUCCESSFUL LOGOUT",Toast.LENGTH_SHORT).show();
            }
        });
    }
    public void opennotificationin(){
        Intent intent = new Intent(this, Innotification.class);
        startActivity(intent);
    }
}
